<?php
session_start();
?>
<!DOCTYPE html>
<html style="font-size: 16px;" lang="en"><head>
    <title>Home</title>
    
<?php include "include/header.php" ?>
        
    <section class="u-clearfix u-image u-shading u-section-1" id="sec-d022" data-image-width="3840" data-image-height="2400">
      <div class="u-clearfix u-sheet u-sheet-1">
        <h2 class="u-align-center u-custom-font u-text u-text-default u-text-1">Welcome to the&nbsp;<br>
          <span class="u-text-custom-color-1">MUSIC </span>
          <span class="u-text-custom-color-1">HOUSE</span>
        </h2>
        <h5 class="u-align-center u-custom-font u-text u-text-default u-text-2"> WITHOUT MUSIC, LIFE WOULD B♭</h5>
        <a href="Shop.php" class="u-border-none u-btn u-btn-round u-button-style u-custom-color-1 u-hover-custom-color-1 u-radius-6 u-btn-1">Shop Now!</a>
      </div>
    </section>
    
<?php include "include/footer.php" ?>
  
</body></html>
