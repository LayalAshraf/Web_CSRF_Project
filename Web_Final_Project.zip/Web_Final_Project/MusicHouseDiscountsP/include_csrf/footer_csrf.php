<footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-13d5"><div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-small-text u-text u-text-variant u-text-1"> © 2023 Developer</p>
      </div></footer>
