    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="description" content="">
    
        <link rel="stylesheet" href="nicepage.css" media="screen">
    <script type="application/ld+json">{
		"logo": "images_csrf/Logo.png"
}</script>

    
  </head>
  <body>
  	<header style="background: #ebdad0; height">
	  	<div style="background: #ebdad0; height: 100px;">
	  	<img src="images_csrf/Logo.png" height=100px align="middle">
	  	
	  	</div>
	  	<p style="color:black; text-align:center;font-family:Courier New; font-size:50px;"><b>Radeem Discount Code!</b></p>
	  <br>	
      </header>
